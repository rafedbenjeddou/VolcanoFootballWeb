/*******f***********

    Competency 19
    Name: 
    Date:
    Description:

*******************/

document.addEventListener("DOMContentLoaded", load);

function load(){
	document.getElementById("dates").reset();
	document.getElementById("goon").addEventListener("click", next);
}


function next(){

}

function nextAgain(){

}
